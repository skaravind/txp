from django.apps import AppConfig


class McontentConfig(AppConfig):
    name = 'mcontent'
